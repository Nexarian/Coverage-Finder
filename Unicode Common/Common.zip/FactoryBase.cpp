// FactoryBase.cpp: implementation of the FactoryBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FactoryBase.h"

//FactoryBase is not a real class, it simply exists so that the templates have a common pointer
